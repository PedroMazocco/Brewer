package br.com.adminfo.model.validation.group;

public interface CnpjGroup {

}
