package br.com.adminfo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.adminfo.model.Estado;

public interface Estados extends JpaRepository<Estado, Long>{

}