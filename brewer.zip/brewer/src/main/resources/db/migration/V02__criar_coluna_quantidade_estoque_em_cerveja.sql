ALTER TABLE cerveja
  ADD quantidade_estoque INTEGER;