ALTER TABLE cerveja
   ADD foto VARCHAR(100),
   ADD content_type VARCHAR(100);